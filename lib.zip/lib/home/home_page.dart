import 'package:feature_discovery/feature_discovery.dart';
import 'package:flutter/material.dart' hide NestedScrollView, showSearch;
import 'package:flutter/services.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  final _androidAppRetain = MethodChannel("android_app_retain");
  var feature1OverflowMode = OverflowMode.clipContent;
  var feature1EnablePulsingAnimation = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  double top = 0;
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        systemNavigationBarIconBrightness:
        Theme.of(context).accentColorBrightness,
        statusBarIconBrightness: Theme.of(context).accentColorBrightness,
        systemNavigationBarColor: Theme.of(context).primaryColor,
      ),
      child: WillPopScope(
        onWillPop: () async {
          // if (_playerKey.currentState != null &&
          //     _playerKey.currentState.initSize > 100) {
          //   _playerKey.currentState.backToMini();
          //   return false;
          // } else if (Platform.isAndroid) {
          //   _androidAppRetain.invokeMethod('sendToBackground');
          //   return false;
          // } else {
          //   return true;
          // }
          return true;
        },
        child: Scaffold(
          key: _scaffoldKey,
          body: new Container(),
        ),
      ),
    );
  }
}

