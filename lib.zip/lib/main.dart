import 'package:feature_discovery/feature_discovery.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vocalcast/auth/login_page.dart';
import 'package:vocalcast/theme/app_state.dart';
import 'intro_slider/app_intro.dart';

///Initial theme settings
 bool intro = false;
Future main() async {
  timeDilation = 1.0;
  WidgetsFlutterBinding.ensureInitialized();
  await FlutterDownloader.initialize();

  final prefs = await SharedPreferences.getInstance();
  if(prefs.containsKey("intro")){
    intro = prefs.getBool("intro")!;
  }else{
    intro = false;
  }

  runApp(
    MultiProvider(
      providers: [
        ListenableProvider(
          create: (_) => ThemeState(),
        ),
      ],
      child: MyApp(),
    ),
  );
  var systemUiOverlayStyle = SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      systemNavigationBarColor: Colors.transparent);
  SystemChrome.setSystemUIOverlayStyle(systemUiOverlayStyle);
  await SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeState>(builder: (context, themeState, child) => FeatureDiscovery(
        child: MaterialApp(
            themeMode: themeState.isDarkModeOn ? ThemeMode.dark : ThemeMode.light,
            debugShowCheckedModeBanner: false,
            title: 'Tsacdop',
            theme: ThemeData.light(),
            darkTheme: ThemeData.dark(),
            home: !intro
                ? SlideIntro()
                : LoginPage())),);
  }
}
