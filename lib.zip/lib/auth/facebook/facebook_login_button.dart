import 'dart:async';
import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:vocalcast/home/home_page.dart';
import 'package:vocalcast/res/global_data.dart';

class FacebookLoginButton extends StatefulWidget {
  @override
  _FacebookLoginButtonState createState() => _FacebookLoginButtonState();
}

class _FacebookLoginButtonState extends State<FacebookLoginButton> {
  // var firebaseAuth = FirebaseAuth.instance;
  //
  // Future<int> _handleSignIn() async {
  //   try {
  //     FacebookLoginResult facebookLoginResult = await _handleFBSignIn();
  //     final accessToken = facebookLoginResult.accessToken.token;
  //     if (facebookLoginResult.status == FacebookLoginStatus.loggedIn) {
  //       final facebookAuthCred = FacebookAuthProvider.credential(accessToken);
  //       final user = await firebaseAuth.signInWithCredential(facebookAuthCred);
  //       print("User : " + user.user.displayName);
  //       return 1;
  //     } else {
  //       return 0;
  //     }
  //   } catch (error) {
  //     return 0;
  //   }
  // }
  //
  // Future<FacebookLoginResult> _handleFBSignIn() async {
  //   FacebookLogin facebookLogin = FacebookLogin();
  //   FacebookLoginResult facebookLoginResult =
  //   await facebookLogin.logIn(['email']);
  //   switch (facebookLoginResult.status) {
  //     case FacebookLoginStatus.cancelledByUser:
  //       print("Cancelled");
  //       break;
  //     case FacebookLoginStatus.error:
  //       print("error");
  //       break;
  //     case FacebookLoginStatus.loggedIn:
  //       print("Logged In");
  //       break;
  //   }
  //   return facebookLoginResult;
  // }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    ColorScheme colorScheme = Theme.of(context).colorScheme;
    return MaterialButton(
        height: 50,
        minWidth: size.width*0.4,
        child: new Row(
          children: [
            new Image.asset("assets/facebook.png", width: 24, height: 24,),
            new SizedBox(width: 10,),
            new Text("Facebook", style: TextStyle(fontSize: 20),)
          ],
        ),
        color: Colors.white,
        textColor: Colors.black,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
        onPressed: () async {
          showCupertinoDialog(
            context: context,
            builder: (context) => CupertinoAlertDialog(
              title: new Text("Processing"),
              content: Center(
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: new CircularProgressIndicator(),
                ),
              ),
            ),
          );
          // int ii = await _handleSignIn();
          Navigator.of(context).pop();
          Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => HomePage(),
              ));
          // if (ii == 1) {
          //   Navigator.push(
          //     context,
          //     MaterialPageRoute(builder: (context) => HomePage()),
          //   );
          // } else {
          //   GlobalData.showSnackBar(
          //       "Authentication Failed!", context, Colors.red);
          // }
        });
  }
}
