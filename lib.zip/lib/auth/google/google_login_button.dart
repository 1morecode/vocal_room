import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:vocalcast/home/home_page.dart';

class GoogleSignInButton extends StatefulWidget {
  @override
  _GoogleSignInButtonState createState() => _GoogleSignInButtonState();
}

class _GoogleSignInButtonState extends State<GoogleSignInButton> {
  // var firebaseAuth = FirebaseAuth.instance;
  //
  // Future<int> _handleSignIn() async {
  //   try {
  //     GoogleSignInAccount googleSignInAccount = await _handleGoogleSignIn();
  //     final googleAuth = await googleSignInAccount.authentication;
  //     final googleAuthCred = GoogleAuthProvider.credential(
  //         idToken: googleAuth.idToken, accessToken: googleAuth.accessToken);
  //     final user = await firebaseAuth.signInWithCredential(googleAuthCred);
  //     print("User : " + user.user.displayName);
  //     return 1;
  //   } catch (error) {
  //     return 0;
  //   }
  // }
  //
  // Future<GoogleSignInAccount> _handleGoogleSignIn() async {
  //   GoogleSignIn googleSignIn = GoogleSignIn(
  //       scopes: ['email', 'https://www.googleapis.com/auth/contacts.readonly']);
  //   GoogleSignInAccount googleSignInAccount = await googleSignIn.signIn();
  //   return googleSignInAccount;
  // }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    ColorScheme colorScheme = Theme.of(context).colorScheme;
    return MaterialButton(
      height: 50,
        minWidth: size.width*0.4,
        child: new Row(
          children: [
            new Image.asset("assets/google.png", width: 24, height: 24,),
            new SizedBox(width: 15,),
            new Text("Google", style: TextStyle(fontSize: 20),)
          ],
        ),
        color: Colors.white,
        textColor: Colors.black,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
        onPressed: () async {
          showCupertinoDialog(
            context: context,
            builder: (context) => CupertinoAlertDialog(
              title: new Text("Processing"),
              content: Center(
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: new CircularProgressIndicator(),
                ),
              ),
            ),
          );
          // int ii = await _handleSignIn();
          Navigator.of(context).pop();
          Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => HomePage(),
              ));
          // if (ii == 1) {
          //   Navigator.push(
          //     context,
          //     MaterialPageRoute(builder: (context) => HomePage()),
          //   );
          // } else {
          //   GlobalData.showSnackBar(
          //       "Authentication Failed!", context, Colors.red);
          // }
        });
  }
}
