import 'package:easy_rich_text/easy_rich_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:vocalcast/auth/facebook/facebook_login_button.dart';
import 'package:vocalcast/auth/google/google_login_button.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Container(
        height: size.height,
        width: size.width,
        decoration: BoxDecoration(
            image: DecorationImage(
          image: AssetImage("assets/login_bg.png"),
          fit: BoxFit.cover,
        )),
        child: new Container(
          height: size.height,
          width: size.width,
          color: Colors.black.withOpacity(0.3),
          child: new SafeArea(
              child: new Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 25),
                child: new Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [GoogleSignInButton(), FacebookLoginButton()],
                ),
              ),
              CupertinoButton(
                onPressed: (){},
                padding: const EdgeInsets.symmetric(vertical: 15),
                child: EasyRichText(
                  "By Continue, to agree our\n"
                      "Terms & Conditions",
                  defaultStyle: TextStyle(color: Colors.white),
                  patternList: [
                    EasyRichTextPattern(
                      targetString: 'Terms',
                      style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary),
                    ),
                    EasyRichTextPattern(
                      targetString: 'Conditions',
                      style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary),
                    ),
                  ],
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          )),
        ),
      ),
    );
  }
}
